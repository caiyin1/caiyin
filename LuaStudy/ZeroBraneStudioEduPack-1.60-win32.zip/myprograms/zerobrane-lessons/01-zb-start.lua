--[[ [previous](00-contents.lua) | [contents](00-contents.lua) | [next](02-controls.lua)

# Hi there!

Welcome to the ZeroBrane Studio tour. ZeroBrane Studio is an application that provides you with everything you need to create and run your own programs. 

In about 10 minutes you will know enough to create, save, and run programs in this environment. Click the [next](02-controls.lua) link at the top of the screen to get started.
]]